gdjs.Untitled_32sceneCode = {};
gdjs.Untitled_32sceneCode.localVariables = [];
gdjs.Untitled_32sceneCode.idToCallbackMap = new Map();
gdjs.Untitled_32sceneCode.GDwolfObjects1= [];
gdjs.Untitled_32sceneCode.GDwolfObjects2= [];
gdjs.Untitled_32sceneCode.GDtitle_9595Objects1= [];
gdjs.Untitled_32sceneCode.GDtitle_9595Objects2= [];
gdjs.Untitled_32sceneCode.GDNewSpriteObjects1= [];
gdjs.Untitled_32sceneCode.GDNewSpriteObjects2= [];
gdjs.Untitled_32sceneCode.GDbellyObjects1= [];
gdjs.Untitled_32sceneCode.GDbellyObjects2= [];
gdjs.Untitled_32sceneCode.GDOperatorPlusBitmapTextObjects1= [];
gdjs.Untitled_32sceneCode.GDOperatorPlusBitmapTextObjects2= [];
gdjs.Untitled_32sceneCode.GDNewSprite2Objects1= [];
gdjs.Untitled_32sceneCode.GDNewSprite2Objects2= [];
gdjs.Untitled_32sceneCode.GDOrangeBubbleButtonObjects1= [];
gdjs.Untitled_32sceneCode.GDOrangeBubbleButtonObjects2= [];
gdjs.Untitled_32sceneCode.GDNewTextObjects1= [];
gdjs.Untitled_32sceneCode.GDNewTextObjects2= [];
gdjs.Untitled_32sceneCode.GDNotJamThirdDimension15Objects1= [];
gdjs.Untitled_32sceneCode.GDNotJamThirdDimension15Objects2= [];
gdjs.Untitled_32sceneCode.GDOrangeBubbleButton2Objects1= [];
gdjs.Untitled_32sceneCode.GDOrangeBubbleButton2Objects2= [];
gdjs.Untitled_32sceneCode.GDSmallGreenPlasticRoundSwitchObjects1= [];
gdjs.Untitled_32sceneCode.GDSmallGreenPlasticRoundSwitchObjects2= [];
gdjs.Untitled_32sceneCode.GDRetryObjects1= [];
gdjs.Untitled_32sceneCode.GDRetryObjects2= [];
gdjs.Untitled_32sceneCode.GDTinyBlackAndWhiteDownVolumeSettingObjects1= [];
gdjs.Untitled_32sceneCode.GDTinyBlackAndWhiteDownVolumeSettingObjects2= [];


gdjs.Untitled_32sceneCode.eventsList0 = function(runtimeScene) {

};gdjs.Untitled_32sceneCode.eventsList1 = function(runtimeScene) {

};gdjs.Untitled_32sceneCode.eventsList2 = function(runtimeScene) {

};gdjs.Untitled_32sceneCode.eventsList3 = function(runtimeScene) {

};gdjs.Untitled_32sceneCode.eventsList4 = function(runtimeScene) {

};gdjs.Untitled_32sceneCode.eventsList5 = function(runtimeScene) {

{


gdjs.Untitled_32sceneCode.eventsList0(runtimeScene);
}


{

gdjs.copyArray(runtimeScene.getObjects("belly"), gdjs.Untitled_32sceneCode.GDbellyObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDbellyObjects1.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDbellyObjects1[i].getBehavior("ButtonFSM").IsClicked(null) ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDbellyObjects1[k] = gdjs.Untitled_32sceneCode.GDbellyObjects1[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDbellyObjects1.length = k;
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(0).add(runtimeScene.getGame().getVariables().getFromIndex(1).getAsNumber());
}
{runtimeScene.getGame().getVariables().getFromIndex(3).sub(1);
}
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("NotJamThirdDimension15"), gdjs.Untitled_32sceneCode.GDNotJamThirdDimension15Objects1);
gdjs.copyArray(runtimeScene.getObjects("OperatorPlusBitmapText"), gdjs.Untitled_32sceneCode.GDOperatorPlusBitmapTextObjects1);
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDOperatorPlusBitmapTextObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDOperatorPlusBitmapTextObjects1[i].getBehavior("RollingCounter").SetValue(runtimeScene.getGame().getVariables().getFromIndex(0).getAsNumber(), null);
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDNotJamThirdDimension15Objects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDNotJamThirdDimension15Objects1[i].getBehavior("RollingCounter").SetValue(runtimeScene.getGame().getVariables().getFromIndex(2).getAsNumber(), null);
}
}
}

}


{


gdjs.Untitled_32sceneCode.eventsList1(runtimeScene);
}


{

gdjs.copyArray(runtimeScene.getObjects("OrangeBubbleButton"), gdjs.Untitled_32sceneCode.GDOrangeBubbleButtonObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(0).getAsNumber() >= runtimeScene.getGame().getVariables().getFromIndex(2).getAsNumber());
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDOrangeBubbleButtonObjects1.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDOrangeBubbleButtonObjects1[i].IsClicked(null) ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDOrangeBubbleButtonObjects1[k] = gdjs.Untitled_32sceneCode.GDOrangeBubbleButtonObjects1[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDOrangeBubbleButtonObjects1.length = k;
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("OrangeBubbleButton2"), gdjs.Untitled_32sceneCode.GDOrangeBubbleButton2Objects1);
{runtimeScene.getGame().getVariables().getFromIndex(0).sub(runtimeScene.getGame().getVariables().getFromIndex(2).getAsNumber());
}
{runtimeScene.getGame().getVariables().getFromIndex(2).add(20);
}
{runtimeScene.getGame().getVariables().getFromIndex(1).add(runtimeScene.getGame().getVariables().getFromIndex(1).getAsNumber());
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDOrangeBubbleButton2Objects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDOrangeBubbleButton2Objects1[i].Activate(true, null);
}
}
}

}


{


gdjs.Untitled_32sceneCode.eventsList2(runtimeScene);
}


{

gdjs.copyArray(runtimeScene.getObjects("OrangeBubbleButton2"), gdjs.Untitled_32sceneCode.GDOrangeBubbleButton2Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDOrangeBubbleButton2Objects1.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDOrangeBubbleButton2Objects1[i].IsClicked(null) ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDOrangeBubbleButton2Objects1[k] = gdjs.Untitled_32sceneCode.GDOrangeBubbleButton2Objects1[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDOrangeBubbleButton2Objects1.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("SmallGreenPlasticRoundSwitch"), gdjs.Untitled_32sceneCode.GDSmallGreenPlasticRoundSwitchObjects1);
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDSmallGreenPlasticRoundSwitchObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDSmallGreenPlasticRoundSwitchObjects1[i].ToggleChecked(null);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("SmallGreenPlasticRoundSwitch"), gdjs.Untitled_32sceneCode.GDSmallGreenPlasticRoundSwitchObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDSmallGreenPlasticRoundSwitchObjects1.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDSmallGreenPlasticRoundSwitchObjects1[i].IsChecked(null) ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDSmallGreenPlasticRoundSwitchObjects1[k] = gdjs.Untitled_32sceneCode.GDSmallGreenPlasticRoundSwitchObjects1[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDSmallGreenPlasticRoundSwitchObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__RepeatEveryXSeconds__Repeat.func(runtimeScene, "auto rubs", runtimeScene.getGame().getVariables().getFromIndex(3).getAsNumber(), null);
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(0).add(runtimeScene.getGame().getVariables().getFromIndex(1).getAsNumber());
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("SmallGreenPlasticRoundSwitch"), gdjs.Untitled_32sceneCode.GDSmallGreenPlasticRoundSwitchObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(0).getAsNumber() >= runtimeScene.getGame().getVariables().getFromIndex(2).getAsNumber());
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDSmallGreenPlasticRoundSwitchObjects1.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDSmallGreenPlasticRoundSwitchObjects1[i].IsChecked(null) ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDSmallGreenPlasticRoundSwitchObjects1[k] = gdjs.Untitled_32sceneCode.GDSmallGreenPlasticRoundSwitchObjects1[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDSmallGreenPlasticRoundSwitchObjects1.length = k;
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(0).sub(runtimeScene.getGame().getVariables().getFromIndex(2).getAsNumber());
}
{runtimeScene.getGame().getVariables().getFromIndex(2).add(20);
}
{runtimeScene.getGame().getVariables().getFromIndex(1).add(runtimeScene.getGame().getVariables().getFromIndex(1).getAsNumber());
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(0).getAsNumber() > 19);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(14744236);
}
}
if (isConditionTrue_0) {
}

}


{


gdjs.Untitled_32sceneCode.eventsList3(runtimeScene);
}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__RepeatEveryXSeconds__Repeat.func(runtimeScene, "save", 0.1, null);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(4).getAsString() == "On");
}
}
if (isConditionTrue_0) {
{gdjs.saveState.createGameSaveStateInStorage(runtimeScene, "save", "default");
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.saveState.restoreGameSaveStateFromStorage(runtimeScene, "save", "default", false);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Retry"), gdjs.Untitled_32sceneCode.GDRetryObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDRetryObjects1.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDRetryObjects1[i].getBehavior("ButtonFSM").IsClicked(null) ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDRetryObjects1[k] = gdjs.Untitled_32sceneCode.GDRetryObjects1[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDRetryObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.saveState.deleteSaveFromStorage(runtimeScene, "save");
}
{runtimeScene.getGame().getVariables().getFromIndex(4).setString("off");
}
}

}


{


gdjs.Untitled_32sceneCode.eventsList4(runtimeScene);
}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(14748196);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "HeynaNEWDEN.mp3", true, 100, 1);
}
}

}


};

gdjs.Untitled_32sceneCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Untitled_32sceneCode.GDwolfObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDwolfObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDtitle_9595Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDtitle_9595Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewSpriteObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewSpriteObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDbellyObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDbellyObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDOperatorPlusBitmapTextObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDOperatorPlusBitmapTextObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewSprite2Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewSprite2Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDOrangeBubbleButtonObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDOrangeBubbleButtonObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewTextObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewTextObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDNotJamThirdDimension15Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDNotJamThirdDimension15Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDOrangeBubbleButton2Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDOrangeBubbleButton2Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDSmallGreenPlasticRoundSwitchObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDSmallGreenPlasticRoundSwitchObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDRetryObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDRetryObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDTinyBlackAndWhiteDownVolumeSettingObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDTinyBlackAndWhiteDownVolumeSettingObjects2.length = 0;

gdjs.Untitled_32sceneCode.eventsList5(runtimeScene);
gdjs.Untitled_32sceneCode.GDwolfObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDwolfObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDtitle_9595Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDtitle_9595Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewSpriteObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewSpriteObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDbellyObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDbellyObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDOperatorPlusBitmapTextObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDOperatorPlusBitmapTextObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewSprite2Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewSprite2Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDOrangeBubbleButtonObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDOrangeBubbleButtonObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewTextObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewTextObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDNotJamThirdDimension15Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDNotJamThirdDimension15Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDOrangeBubbleButton2Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDOrangeBubbleButton2Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDSmallGreenPlasticRoundSwitchObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDSmallGreenPlasticRoundSwitchObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDRetryObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDRetryObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDTinyBlackAndWhiteDownVolumeSettingObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDTinyBlackAndWhiteDownVolumeSettingObjects2.length = 0;


return;

}

gdjs['Untitled_32sceneCode'] = gdjs.Untitled_32sceneCode;
